﻿using System.ComponentModel.DataAnnotations;

namespace CursosAJAX.Models
{
    public class ProfesorDTO
    {
        public int ProfesorId { get;  set; }
        [Display(Name = "Nombres del profesor")]
        public string Nombres { get;  set; }
        [Display(Name = "Apellidos del profesor")]
        public string Apellidos { get;  set; }
        public bool Disabled { get; set; }
    }
}
