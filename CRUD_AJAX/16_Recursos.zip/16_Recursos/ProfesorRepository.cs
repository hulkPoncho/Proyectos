﻿using CursosAJAX.Dominio.IRepositories;
using CursosAJAX.Dominio.Models;
using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CursosAJAX.Persistencia.Repositories
{
    public class ProfesorRepository : IProfesorRepository
    {
        private readonly CursosCrudContext _context;
        public ProfesorRepository(CursosCrudContext context)
        {
            _context = context;
        }

        public async Task<List<ProfesorDTO>> ConsultaProfesores()
        {
            var profesores = await(from t in _context.Profesors
                                   select new ProfesorDTO
                                   {
                                       ProfesorId = t.ProfesorId,
                                       Nombres = t.Nombres,
                                       Apellidos = t.Apellidos
                                   }).ToListAsync();
            return profesores;
        }

        public async Task<ProfesorDTO> ConsultarProfesor(ProfesorDTO modelo)
        {
            modelo = await(from t in _context.Profesors
                           where t.ProfesorId == modelo.ProfesorId
                           select new ProfesorDTO
                           {
                               ProfesorId = t.ProfesorId,
                               Nombres = t.Nombres,
                               Apellidos = t.Apellidos
                           }).FirstOrDefaultAsync() ?? new ProfesorDTO();
            return modelo;

        }

        private async Task<Profesor> CrearProfesor(ProfesorDTO modelo, RespuestaDTO _RespuestaDTO)
        {
            Profesor? _Profesor = new()
            {
                Nombres = modelo.Nombres,
                Apellidos = modelo.Apellidos
            };
            await _context.Profesors.AddAsync(_Profesor);
            _RespuestaDTO.Exito = "Se creó el profesor de manera exitosa";
            return _Profesor;
        }

        private async Task<bool> ExisteProfesor(ProfesorDTO modelo)
        {
            return await
                                _context.Profesors.Where(
                                    s => s.Nombres == modelo.Nombres
                                    && s.Apellidos == modelo.Apellidos
                                    && s.ProfesorId != modelo.ProfesorId
                                    ).AnyAsync();
        }


        public async Task<RespuestaDTO> CrearActualizarProfesor(ProfesorDTO modelo)
        {
            var _RespuestaDTO = new RespuestaDTO();
            var _Profesor = new Profesor();
            if (modelo.ProfesorId == 0)
            {
                bool existe = await ExisteProfesor(modelo);

                if (existe)
                {
                    _RespuestaDTO.Error = "Ya existe un profesor con el nombre indicado";
                }
                else
                {
                    _Profesor = await CrearProfesor(modelo, _RespuestaDTO);
                }
            }
            else
            {
                _Profesor =
                    await
                    _context.Profesors.Where(s => s.ProfesorId == modelo.ProfesorId).
                    FirstOrDefaultAsync();

                if (_Profesor == null)
                {
                    _RespuestaDTO.Error = "No se encontró el profesor indicado";
                }
                else
                {
                    bool existe = await ExisteProfesor(modelo);
                    if (existe)
                    {
                        _RespuestaDTO.Error = "Ya existe un profesor con el nombre indicado";
                    }
                    else
                    {
                        _Profesor.Nombres = modelo.Nombres;
                        _Profesor.Apellidos = modelo.Apellidos;
                        _RespuestaDTO.Exito = "Se actualizó la información de manera exitosa";
                    }
                }
            }

            if (string.IsNullOrEmpty(_RespuestaDTO.Error))
            {
                await _context.SaveChangesAsync();
            }

            return _RespuestaDTO;

        }

        public async Task<RespuestaDTO> EliminarProfesor(ProfesorDTO modelo)
        {
            var _RespuestaDTO = new RespuestaDTO();
            var _Profesor =
                    await
                _context.Profesors.
                Where(s => s.ProfesorId == modelo.ProfesorId).FirstOrDefaultAsync();

            if (_Profesor != null)
            {
                var ExistePrograma = await
                    _context.CursoProfesors.Where(s => s.ProfesorId == modelo.ProfesorId).AnyAsync();

                if (ExistePrograma)
                {
                    _RespuestaDTO.Error = "No se puede realizar la eliminación, existe un programa asociado";
                }
                else
                {
                    _context.Profesors.Remove(_Profesor);
                    await _context.SaveChangesAsync();
                    _RespuestaDTO.Exito = "Se eliminó el profesor de manera exitosa";
                }
            }
            else
            {
                _RespuestaDTO.Error = "No se encontró el profesor indicado";
            }

            return _RespuestaDTO;

        }

        public async Task<List<SelectListItem>> ListaSeleccionProfesor()
        {
            var lista = await _context.Profesors.Select(u => new SelectListItem
            {
                Text = u.Nombres + " " + u.Apellidos,
                Value = "" + u.ProfesorId
            }).ToListAsync();

            lista.Insert(0,
                new SelectListItem
                {
                    Text = "Seleccione una opción",
                    Value = "0",
                }
            );
            return lista;
        }
    }
}
