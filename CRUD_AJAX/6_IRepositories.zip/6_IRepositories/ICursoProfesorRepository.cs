﻿using CursosAJAX.Models;

namespace CursosAJAX.Dominio.IRepositories
{
    public interface ICursoProfesorRepository
    {
        Task<List<ProgramaDTO>> ConsultaProgramas();
        Task<RespuestaDTO> CrearActualizarPrograma(ProgramaDTO modelo);
        Task<RespuestaDTO> EliminarPrograma(ProgramaDTO modelo);
        Task<ProgramaDTO> ConsultarPrograma(ProgramaDTO modelo);
    }
}
