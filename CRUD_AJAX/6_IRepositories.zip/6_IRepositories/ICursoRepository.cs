﻿using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CursosAJAX.Dominio.IRepositories
{
    public interface ICursoRepository
    {
        Task<List<CursoDTO>> ConsultaCursos();
        Task<RespuestaDTO> CrearActualizarCurso(CursoDTO modelo);
        Task<RespuestaDTO> EliminarCurso(CursoDTO modelo);
        Task<CursoDTO> ConsultarCurso(CursoDTO modelo);
        Task<List<SelectListItem>> ListaSeleccionCursos();
    }
}
