﻿using System.ComponentModel.DataAnnotations;

namespace CursosAJAX.Models
{
    public class CursoDTO
    {
        public int CursoId { get; set; }

        [Display(Name = "Nombre del curso")]
        public string Nombre { get; set; }

        [Display(Name = "Descripcion")]
        public string Descripcion { get; set; }
        public bool Disabled { get; set; }
    }
}
