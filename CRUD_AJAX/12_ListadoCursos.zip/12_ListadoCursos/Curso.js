﻿function ListarCursos() {
	EnvioGenerico("/Curso/Listado", null, "IdListaCursos")
}

function FormularioCurso(CursoId, Disabled) {
    Global.CursoId = CursoId == undefined ? 0 : CursoId;
    Global.Disabled = Disabled == undefined ? false : true;
    const model = {
        CursoId: CursoId,
        Disabled: Disabled
    }
    EnvioGenerico("/Curso/Formulario", model, ModalCrearCurso)
}

function ModalCrearCurso(html) {
    // const html = `string text`;

    const CursoId = Global.CursoId
    const Disabled = Global.Disabled;
    const title = CursoId == 0 ? "Nuevo curso" :
        (Disabled == true ? "Detalle del curso" : "Edición del curso")
    const confirmButtonText = CursoId == 0 ? "Guardar curso" :
        "Actualizar curso";

    const model = {
        title: title,
        html: html,
        confirmButtonText: confirmButtonText,
        showConfirmButton: !Disabled
    };
    ModalCaptura(model, GuardarCurso);
}

function GuardarCurso() {
    model = {
        Nombre: $("#NombreCurso").val(),
        Descripcion: $("#DescripcionCurso").val(),
        CursoId: Global.CursoId
    };
    EnvioGenerico("/Curso/GuardarCurso", model, MensajeAccionCurso)
}

function MensajeAccionCurso(respuesta) {
    if (respuesta.Error != "") {
        AlertaError(respuesta.Error);
    }
    else {
        EnvioGenerico("/Curso/Listado", null, "IdListaCursos")
        AlertaExito(respuesta.Exito);
    }
}

function EliminarCursoForm(CursoId, Nombre) {
    Global.CursoId = CursoId;
    const model = {
        title: "Esta seguro de eliminar el curso: [" + Nombre + "]",
        confirmButtonText: "Eliminar curso",
        cancelButtonText: "Cancelar"
    };
    Confirm(model, EliminarCurso);
}

function EliminarCurso() {
    const model = {
        CursoId: Global.CursoId
    };
    EnvioGenerico("/Curso/EliminarCurso", model, MensajeAccionCurso)
}