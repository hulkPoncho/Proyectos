﻿using CursosAJAX.Dominio.IRepositories;
using CursosAJAX.Dominio.Models;
using CursosAJAX.Models;
using Microsoft.EntityFrameworkCore;

namespace CursosAJAX.Persistencia.Repositories
{
    public class CursoProfesorRepository : ICursoProfesorRepository
    {
        private readonly CursosCrudContext _context;
        public CursoProfesorRepository(CursosCrudContext context)
        {
            _context = context;
        }

        public async Task<List<ProgramaDTO>> ConsultaProgramas()
        {
            var programas = await(from t in _context.CursoProfesors
                                  select new ProgramaDTO
                                  {
                                      CursoProfesorId = t.CursoProfesorId,
                                      NombreCurso = t.Curso.Nombre,
                                      DescripcionCurso = t.Curso.Descripcion,
                                      NombreProfesor = t.Profesor.Nombres + " " + t.Profesor.Apellidos,
                                      FechaRegistro = t.FechaRegistro
                                  }).ToListAsync();
            return programas;
        }

        public async Task<ProgramaDTO> ConsultarPrograma(ProgramaDTO modelo)
        {
            modelo = await(from t in _context.CursoProfesors
                           where t.CursoProfesorId == modelo.CursoProfesorId
                           select new ProgramaDTO
                           {
                               NombreCurso = t.Curso.Nombre,
                               DescripcionCurso = t.Curso.Descripcion,
                               NombreProfesor = t.Profesor.Nombres + " " +
                                   t.Profesor.Apellidos,
                               FechaRegistro = t.FechaRegistro,
                               CursoId = t.CursoId,
                               ProfesorId = t.ProfesorId
                           }).FirstOrDefaultAsync() ?? new ProgramaDTO();

            return modelo;
        }

        public async Task<RespuestaDTO> CrearActualizarPrograma(ProgramaDTO modelo)
        {

            var _RespuestaDTO = new RespuestaDTO();
            var _Programa = new CursoProfesor();
            if (modelo.CursoProfesorId == 0)
            {
                bool existe = await ExistePrograma(modelo);

                if (existe)
                {
                    _RespuestaDTO.Error = "Ya existe un programa con la información indicada";
                }
                else
                {
                    _Programa = CrearCursoProfesor(modelo, _RespuestaDTO);
                }
            }
            else
            {
                _Programa =
                    await
                    _context.CursoProfesors.Where(s => s.CursoProfesorId ==
                     modelo.CursoProfesorId)
                    .FirstOrDefaultAsync();
                if (_Programa == null)
                {
                    _RespuestaDTO.Error = "No se encontró el programa indicado";
                }
                else
                {
                    bool existe = await ExistePrograma(modelo);

                    if (existe)
                    {
                        _RespuestaDTO.Error = "Ya existe un programa con la información indicada";
                    }
                    else
                    {
                        _Programa.CursoId = modelo.CursoId;
                        _Programa.ProfesorId = modelo.ProfesorId;
                        _Programa.FechaRegistro = DateTime.Now;
                        _RespuestaDTO.Exito = "Se actualizó el programa de manera exitosa";
                    }
                }
            }

            if (string.IsNullOrEmpty(_RespuestaDTO.Error))
            {
                await _context.SaveChangesAsync();
            }

            return _RespuestaDTO;
        }

        private async Task<bool> ExistePrograma(ProgramaDTO modelo)
        {
            return await
                _context.CursoProfesors.Where(
                    s => s.CursoId == modelo.CursoId
                    && s.ProfesorId == modelo.ProfesorId
                    && s.CursoProfesorId != modelo.CursoProfesorId
                    ).AnyAsync();
        }

        private CursoProfesor CrearCursoProfesor(ProgramaDTO modelo, RespuestaDTO _RespuestaDTO)
        {
            CursoProfesor? _Programa = new CursoProfesor
            {
                CursoId = modelo.CursoId,
                ProfesorId = modelo.ProfesorId,
                FechaRegistro = DateTime.Now
            };
            _context.CursoProfesors.Add(_Programa);
            _RespuestaDTO.Exito = "Se creó el programa de manera exitosa";
            return _Programa;
        }

        public async Task<RespuestaDTO> EliminarPrograma(ProgramaDTO modelo)
        {
            var _RespuestaDTO = new RespuestaDTO();
            var _Programa =
                    await
                _context.CursoProfesors.Where(s => s.CursoProfesorId ==
                modelo.CursoProfesorId).FirstOrDefaultAsync();

            if (_Programa != null)
            {
                _context.CursoProfesors.Remove(_Programa);
                await _context.SaveChangesAsync();
                _RespuestaDTO.Exito = "Se eliminó el programa de manera exitosa";
            }
            else
            {
                _RespuestaDTO.Error = "No se encontró el programa indicado";
            }

            return _RespuestaDTO;
        }
    }
}
