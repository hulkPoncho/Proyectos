﻿using CursosAJAX.Dominio.IRepositories;
using CursosAJAX.Dominio.Models;
using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CursosAJAX.Persistencia.Repositories
{
    public class CursoRepository : ICursoRepository
    {
        private readonly CursosCrudContext _CursosCrudContext;

        public CursoRepository(CursosCrudContext CursosCrudContext)
        {
            _CursosCrudContext = CursosCrudContext;
        }

        public async Task<List<CursoDTO>> ConsultaCursos()
        {
            var cursos = await
                (from t in _CursosCrudContext.Cursos
                 select new CursoDTO
                 {
                     CursoId = t.CursoId,
                     Nombre = t.Nombre,
                     Descripcion = t.Descripcion
                 }).ToListAsync();
            return cursos;
        }

        public async Task<CursoDTO> ConsultarCurso(CursoDTO modelo)
        {
            modelo = await(from t in _CursosCrudContext.Cursos
                           where t.CursoId == modelo.CursoId
                           select new CursoDTO
                           {
                               CursoId = t.CursoId,
                               Nombre = t.Nombre,
                               Descripcion = t.Descripcion
                           }).FirstOrDefaultAsync() ?? new CursoDTO();

            return modelo;
        }

        public async Task<RespuestaDTO> CrearActualizarCurso(CursoDTO modelo)
        {
            var _RespuestaDTO = new RespuestaDTO();
            var _Curso = new Curso();
            // Crea un curso
            if (modelo.CursoId == 0)
            {
                bool existe = await ExisteCurso(modelo);

                if (existe)
                {
                    _RespuestaDTO.Error = "Ya existe un curso con el nombre indicado";
                }
                else
                {
                    _Curso = CrearCurso(modelo, _RespuestaDTO);
                }
            }
            // Actualiza un curso
            else
            {
                _Curso =
                    await
                    _CursosCrudContext.Cursos.Where(s => s.CursoId == modelo.CursoId).
                    FirstOrDefaultAsync();
                if (_Curso == null)
                {
                    _RespuestaDTO.Error = "No se encontró el curso indicado";
                }
                else
                {
                    bool existe = await ExisteCurso(modelo);
                    if (existe)
                    {
                        _RespuestaDTO.Error = "Ya existe un curso con el nombre indicado";
                    }
                    else
                    {
                        _Curso.Nombre = modelo.Nombre;
                        _Curso.Descripcion = modelo.Descripcion;
                        _RespuestaDTO.Exito = "Se actualizó de manera correcta";
                    }
                }
            }

            if (string.IsNullOrEmpty(_RespuestaDTO.Error))
            {
                await _CursosCrudContext.SaveChangesAsync();
            }
            return _RespuestaDTO;
        }

        private Curso CrearCurso(CursoDTO modelo, RespuestaDTO _RespuestaDTO)
        {
            Curso? _Curso = new()
            {
                Nombre = modelo.Nombre,
                Descripcion = modelo.Descripcion
            };
            _CursosCrudContext.Cursos.Add(_Curso);
            _RespuestaDTO.Exito = "Se creó el curso de manera exitosa";
            return _Curso;
        }

        private async Task<bool> ExisteCurso(CursoDTO modelo)
        {
            return await
                                 _CursosCrudContext.Cursos.Where(
                                     s => s.Nombre == modelo.Nombre
                                     && s.CursoId != modelo.CursoId
                                     ).AnyAsync();
        }

        public async Task<RespuestaDTO> EliminarCurso(CursoDTO modelo)
        {
            var _RespuestaDTO = new RespuestaDTO();
            var _Curso =
                    await
                _CursosCrudContext.Cursos.Where(s => s.CursoId == modelo.CursoId).FirstOrDefaultAsync();

            if (_Curso != null)
            {
                var ExistePrograma = await
                    _CursosCrudContext.CursoProfesors.Where(s => s.CursoId == modelo.CursoId).
                    AnyAsync();

                if (ExistePrograma)
                {
                    _RespuestaDTO.Error = "Existe un programa asociado al curso, no se puede realizar la eliminaciòn";
                }
                else
                {
                    _CursosCrudContext.Cursos.Remove(_Curso);
                    await _CursosCrudContext.SaveChangesAsync();
                    _RespuestaDTO.Exito = "Se eliminó el curso de manera exitosa";
                }
            }
            else
            {
                _RespuestaDTO.Error = "No se encontró el curso indicado";
            }

            return _RespuestaDTO;

        }

        public async Task<List<SelectListItem>> ListaSeleccionCursos()
        {
            var lista = await _CursosCrudContext.Cursos.Select(u => new SelectListItem
            {
                Text = u.Nombre,
                Value = "" + u.CursoId
            }).ToListAsync();

            lista.Insert(0,
                new SelectListItem
                {
                    Text = "Seleccione una opción",
                    Value = "0"
                }
            );
            return lista;
        }
    }
}
