﻿namespace CursosAJAX.Models
{
    public class RespuestaDTO
    {
        public RespuestaDTO()
        {
            Error = "";
            Exito = "";
        }

        public string Error { get; set; }
        public string Exito { get; set; }
    }
}
