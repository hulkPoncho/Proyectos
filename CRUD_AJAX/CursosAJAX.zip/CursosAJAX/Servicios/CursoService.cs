﻿using CursosAJAX.Dominio.IRepositories;
using CursosAJAX.Dominio.IServices;
using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CursosAJAX.Servicios
{
    public class CursoService : ICursoService
    {
        private readonly ICursoRepository _ICursoRepository;

        public CursoService(ICursoRepository iCursoRepository)
        {
            _ICursoRepository = iCursoRepository;
        }


        public async Task<List<CursoDTO>> ConsultaCursos()
        {
            return await _ICursoRepository.ConsultaCursos();
        }

        public async Task<CursoDTO> ConsultarCurso(CursoDTO modelo)
        {
            return await _ICursoRepository.ConsultarCurso(modelo);
        }

        public async Task<RespuestaDTO> CrearActualizarCurso(CursoDTO modelo)
        {
            return await _ICursoRepository.CrearActualizarCurso(modelo);
        }

        public async Task<RespuestaDTO> EliminarCurso(CursoDTO modelo)
        {
            return await _ICursoRepository.EliminarCurso(modelo);
        }

        public async Task<List<SelectListItem>> ListaSeleccionCursos()
        {
            return await _ICursoRepository.ListaSeleccionCursos();
        }
    }
}
