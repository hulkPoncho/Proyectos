﻿using CursosAJAX.Dominio.IRepositories;
using CursosAJAX.Dominio.IServices;
using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CursosAJAX.Servicios
{
    public class ProfesorService : IProfesorService
    {
        private readonly IProfesorRepository _IProfesorRepository;

        public ProfesorService(IProfesorRepository iProfesorRepository)
        {
            _IProfesorRepository = iProfesorRepository;
        }

        public async Task<List<ProfesorDTO>> ConsultaProfesores()
        {
            return await _IProfesorRepository.ConsultaProfesores();
        }

        public async Task<ProfesorDTO> ConsultarProfesor(ProfesorDTO modelo)
        {
            return await _IProfesorRepository.ConsultarProfesor(modelo);
        }

        public async Task<RespuestaDTO> CrearActualizarProfesor(ProfesorDTO modelo)
        {
            return await _IProfesorRepository.CrearActualizarProfesor(modelo);
        }

        public async Task<RespuestaDTO> EliminarProfesor(ProfesorDTO modelo)
        {
            return await _IProfesorRepository.EliminarProfesor(modelo);
        }

        public async Task<List<SelectListItem>> ListaSeleccionProfesor()
        {
            return await _IProfesorRepository.ListaSeleccionProfesor();
        }
    }
}
