﻿using CursosAJAX.Dominio.IRepositories;
using CursosAJAX.Dominio.IServices;
using CursosAJAX.Models;

namespace CursosAJAX.Servicios
{
    public class CursoProfesorService : ICursoProfesorService
    {
        private readonly ICursoProfesorRepository _ICursoProfesorRepository;

        public CursoProfesorService(ICursoProfesorRepository iCursoProfesorRepository)
        {
            _ICursoProfesorRepository = iCursoProfesorRepository;
        }

        public async Task<List<ProgramaDTO>> ConsultaProgramas()
        {
            return await _ICursoProfesorRepository.ConsultaProgramas();
        }

        public async Task<ProgramaDTO> ConsultarPrograma(ProgramaDTO modelo)
        {
            return await _ICursoProfesorRepository.ConsultarPrograma(modelo);
        }

        public async Task<RespuestaDTO> CrearActualizarPrograma(ProgramaDTO modelo)
        {
            return await _ICursoProfesorRepository.CrearActualizarPrograma(modelo);
        }

        public async Task<RespuestaDTO> EliminarPrograma(ProgramaDTO modelo)
        {
            return await _ICursoProfesorRepository.EliminarPrograma(modelo);
        }
    }
}
