﻿function ListarProgramas() {
    EnvioGenerico("/CursoProfesor/Listado", null, "IdListaProgramas")
}

function FormularioPrograma(CursoProfesorId, Disabled) {
    Global.CursoProfesorId = CursoProfesorId == undefined ? 0 : CursoProfesorId;
    Global.Disabled = Disabled == undefined ? false : true;
    const model = {
        CursoProfesorId: CursoProfesorId,
        Disabled: Disabled
    }
    EnvioGenerico("/CursoProfesor/Formulario", model, ModalCrearPrograma)
}

function ModalCrearPrograma(html) {
    // const html = `string text`;

    const CursoProfesorId = Global.CursoProfesorId;
    const Disabled = Global.Disabled;
    const title = CursoProfesorId == 0 ? "Nuevo programa" :
        (Disabled == true ? "Detalle de programa" : "Edición de programa")
    const confirmButtonText = CursoProfesorId == 0 ? "Guardar información" :
        "Actualizar información";
    const model = {
        title: title,
        html: html,
        confirmButtonText: confirmButtonText,
        showConfirmButton: !Disabled
    };
    ModalCaptura(model, GuardarPrograma);
}

function GuardarPrograma() {
    model = {
        //$("#CursoId option:selected").text();
        CursoProfesorId: Global.CursoProfesorId,
        CursoId: $("#CursoId option:selected").val(),
        ProfesorId: $("#ProfesorId option:selected").val(),
    };
    if (model.CursoId == 0 || model.ProfesorId == 0) {
        AlertaError("Debe índicar la información requerida");
    }
    else {
        EnvioGenerico("/CursoProfesor/GuardarPrograma", model, MensajeAccionPrograma)
    }
}

function MensajeAccionPrograma(respuesta) {
    if (respuesta.Error != "") {
        AlertaError(respuesta.Error);
    }
    else {
        EnvioGenerico("/CursoProfesor/Listado", null, "IdListaProgramas")
        AlertaExito(respuesta.Exito);
    }
}

function EliminarProgramaForm(CursoProfesorId) {
    Global.CursoProfesorId = CursoProfesorId;
    const model = {
        title: "Esta seguro de la eliminación",
        confirmButtonText: "Eliminar información",
        cancelButtonText: "Cancelar"
    };
    Confirm(model, EliminarPrograma);
}

function EliminarPrograma() {
    const model = {
        CursoProfesorId: Global.CursoProfesorId
    };
    EnvioGenerico("/CursoProfesor/EliminarPrograma", model, MensajeAccionPrograma)
}