﻿let Global = {
    CursoProfesorId: 0,
    ProfesorId: 0,
    CursoId: 0,
    Disabled: false
}

function EnvioGenerico(controlador, modelo, callback) {

    $.ajax({
        type: 'POST',
        url: controlador,
        data: modelo,
        async: false,
        cache: false,
        success: function (resultado) {

            //Obtengo el tipo de dato del argumento callback
            tipoCallback = typeof (callback);

            if (tipoCallback == "function") {
                //Ejecuta la funciòn callback teniendo como argumento lo que respondió
                //el servidor (resultado)
                callback(resultado);
            }
            else {
                $("#" + callback).html(resultado);
            }
        },
        error: function (errorHtml) {
            if (errorHtml.responseJSON != undefined) {
                alert(errorHtml.responseJSON.error)
            }
            else {
                alert(controlador + ":" + JSON.stringify(errorHtml));
            }
        },
        complete: function () {

        }
    });
}

function ModalCaptura(model, action) {

    // https://sweetalert2.github.io/

    Swal.fire({
        title: model.title,
        html: model.html,
        heightAuto: false,
        width: 800,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        showCloseButton: true,
        showCancelButton: true,
        showConfirmButton: model.showConfirmButton,
        confirmButtonText: '<i class="far fa-save"></i> ' + model.confirmButtonText,
        cancelButtonText: '<i class="far fa-eraser"></i> Cerrar'
    }).then((result) => {
        if (result.isConfirmed) {
            action();
        }
    })
}

function AlertaExito(message) {
    Swal.fire({
        position: 'top-end',
        icon: 'success',
        title: message,
        showConfirmButton: false,
        timer: 3000
    })
}

function AlertaError(message) {
    Swal.fire({
        position: 'top-end',
        icon: 'error',
        title: message,
        showConfirmButton: false,
        timer: 3000
    })
}

function Confirm(model, action) {
    Swal.fire({
        title: model.title,
        showDenyButton: false,
        showCancelButton: true,
        confirmButtonText: model.confirmButtonText,
        //denyButtonText: model.denyButtonText,
        cancelButtonText: model.cancelButtonText,
    }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            action();
        }
        //} else if (result.isDenied) {}
    })
}