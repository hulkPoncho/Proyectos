﻿using CursosAJAX.Models;

namespace CursosAJAX.Dominio.IServices
{
    public interface ICursoProfesorService
    {
        Task<List<ProgramaDTO>> ConsultaProgramas();
        Task<RespuestaDTO> CrearActualizarPrograma(ProgramaDTO modelo);
        Task<RespuestaDTO> EliminarPrograma(ProgramaDTO modelo);
        Task<ProgramaDTO> ConsultarPrograma(ProgramaDTO modelo);

    }
}
