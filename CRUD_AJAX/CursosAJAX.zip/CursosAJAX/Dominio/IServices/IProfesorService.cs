﻿using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CursosAJAX.Dominio.IServices
{
    public interface IProfesorService
    {
        Task<List<ProfesorDTO>> ConsultaProfesores();
        Task<RespuestaDTO> CrearActualizarProfesor(ProfesorDTO modelo);
        Task<RespuestaDTO> EliminarProfesor(ProfesorDTO modelo);
        Task<ProfesorDTO> ConsultarProfesor(ProfesorDTO modelo);
        Task<List<SelectListItem>> ListaSeleccionProfesor();
    }
}
