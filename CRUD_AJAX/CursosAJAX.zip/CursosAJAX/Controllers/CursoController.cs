﻿using CursosAJAX.Dominio.IServices;
using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc;

namespace CursosAJAX.Controllers
{
    public class CursoController : Controller
    {
        private readonly ICursoService _ICursoService;
        public CursoController(ICursoService iCursoService)
        {
            _ICursoService = iCursoService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Listado()
        {
            var cursos = await _ICursoService.ConsultaCursos();
            return PartialView(cursos);
        }

        public async Task<IActionResult> Formulario(CursoDTO modelo)
        {
            var disabled = modelo.Disabled;
            if (modelo.CursoId != 0)
            {
                modelo = await _ICursoService.ConsultarCurso(modelo);
            }
            modelo.Disabled = disabled;
            return PartialView(modelo);
        }

        public async Task<JsonResult> GuardarCurso(CursoDTO modelo)
        {
            var respuesta = new RespuestaDTO();
            if (string.IsNullOrEmpty(modelo.Nombre))
            {
                respuesta.Error = "Debe capturar el nombre del curso";
                return Json(respuesta);
            }

            if (string.IsNullOrEmpty(modelo.Descripcion))
            {
                respuesta.Error = "Debe capturar la descripcion del curso";
                return Json(respuesta);
            }
            try
            {
                respuesta = await _ICursoService.CrearActualizarCurso(modelo);
            }
            catch (Exception)
            {
                respuesta.Exito = "";
                respuesta.Error = "Ocurrió un error, favor de revisar";
            }
            return Json(respuesta);
        }

        public async Task<JsonResult> EliminarCurso(CursoDTO modelo)
        {
            var respuesta = new RespuestaDTO();
            try
            {
                respuesta = await _ICursoService.EliminarCurso(modelo);
            }
            catch (Exception)
            {
                respuesta.Error = "Ocurrió un error, favor de revisar";
            }
            return Json(respuesta);
        }

    }
}
