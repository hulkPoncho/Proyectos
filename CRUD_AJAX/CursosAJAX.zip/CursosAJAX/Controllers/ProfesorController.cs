﻿using CursosAJAX.Dominio.IServices;
using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc;

namespace CursosAJAX.Controllers
{
    public class ProfesorController : Controller
    {

        private readonly IProfesorService _IProfesorService;
        public ProfesorController(IProfesorService iProfesorService)
        {
            _IProfesorService = iProfesorService;
        }
        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Listado()
        {
            var profesores = await _IProfesorService.ConsultaProfesores();
            return PartialView(profesores);
        }

        public async Task<IActionResult> Formulario(ProfesorDTO modelo)
        {
            var disabled = modelo.Disabled;
            if (modelo.ProfesorId != 0)
            {
                modelo = await _IProfesorService.ConsultarProfesor(modelo);
            }
            modelo.Disabled = disabled;
            return PartialView(modelo);
        }

        public async Task<JsonResult> GuardarProfesor(ProfesorDTO modelo)
        {
            var respuesta = new RespuestaDTO();
            if (string.IsNullOrEmpty(modelo.Nombres))
            {
                respuesta.Error = "Debe capturar el(los) nombre(s) del profesor";
                return Json(respuesta);
            }

            if (string.IsNullOrEmpty(modelo.Apellidos))
            {
                respuesta.Error = "Debe capturar el(los) apellido(s) del profesor";
                return Json(respuesta);
            }
            try
            {
                respuesta = await _IProfesorService.CrearActualizarProfesor(modelo);
            }
            catch (Exception)
            {
                respuesta.Error = "Ocurrió un error, favor de revisar";
            }
            return Json(respuesta);
        }

        [HttpPost]
        public async Task<JsonResult> EliminarProfesor(ProfesorDTO modelo)
        {
            var respuesta = new RespuestaDTO();
            try
            {
                respuesta = await _IProfesorService.EliminarProfesor(modelo);
            }
            catch (Exception)
            {
                respuesta.Error = "Ocurrió un error, favor de revisar";
            }
            return Json(respuesta);
        }
    }
}
