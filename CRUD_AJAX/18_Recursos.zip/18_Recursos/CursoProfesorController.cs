﻿using CursosAJAX.Dominio.IServices;
using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CursosAJAX.Controllers
{
    public class CursoProfesorController : Controller
    {

        private readonly ICursoProfesorService _ICursoProfesorService;
        private readonly ICursoService _ICursoService;
        private readonly IProfesorService _IProfesorService;
        public CursoProfesorController
            (ICursoProfesorService iCursoProfesorService,
            ICursoService iCursoService,
            IProfesorService iProfesorService)
        {
            _ICursoProfesorService = iCursoProfesorService;
            _ICursoService = iCursoService;
            _IProfesorService = iProfesorService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Listado()
        {
            var programas = await _ICursoProfesorService.ConsultaProgramas();
            return PartialView(programas);
        }

        public async Task<IActionResult> Formulario(ProgramaDTO modelo)
        {
            var disabled = modelo.Disabled;
            if (modelo.CursoProfesorId != 0)
            {
                modelo = await _ICursoProfesorService.ConsultarPrograma(modelo);
            }
            var ListaCursos = await _ICursoService.ListaSeleccionCursos();
            modelo.ListaCursos = new SelectList(ListaCursos, "Value", "Text", modelo.CursoId);
            var ListaProfesores = await _IProfesorService.ListaSeleccionProfesor();
            modelo.ListaProfesores = new SelectList(ListaProfesores, "Value", "Text", 
                modelo.ProfesorId);
            modelo.Disabled = disabled;
            return PartialView(modelo);
        }


        public async Task<JsonResult> GuardarPrograma(ProgramaDTO modelo)
        {
            var respuesta = new RespuestaDTO();
            if (modelo.CursoId == 0)
            {
                respuesta.Error = "Debe seleccionar un curso";
                return Json(respuesta);
            }

            if (modelo.ProfesorId == 0)
            {
                respuesta.Error = "Debe seleccionar un profesor";
                return Json(respuesta);
            }
            try
            {
                respuesta = await _ICursoProfesorService.CrearActualizarPrograma(modelo);
            }
            catch (Exception)
            {
                respuesta.Exito = "";
                respuesta.Error = "Ocurrió un error, favor de revisar";
            }
            return Json(respuesta);
        }

        public async Task<JsonResult> EliminarPrograma(ProgramaDTO modelo)
        {
            var respuesta = new RespuestaDTO();
            try
            {
                respuesta = await _ICursoProfesorService.EliminarPrograma(modelo);
            }
            catch (Exception)
            {
                respuesta.Error = "Ocurrió un error, favor de revisar";
            }
            return Json(respuesta);
        }
    }
}
