﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace CursosAJAX.Models
{
    public class ProgramaDTO
    {
        public int CursoProfesorId { get; set; }
        [Display(Name = "Nombre del curso")]
        public string NombreCurso { get; set; }
        public string DescripcionCurso { get; set; }
        [Display(Name = "Nombre del profesor")]
        public string NombreProfesor { get; set; }
        [Display(Name = "Fecha de registro")]
        public DateTime? FechaRegistro { get; set; }
        public int CursoId { get; set; }
        public int ProfesorId { get; set; }
        public bool Disabled { get; set; }
        public SelectList ListaCursos { get; set; }
        public SelectList ListaProfesores { get; set; }
    }
}
