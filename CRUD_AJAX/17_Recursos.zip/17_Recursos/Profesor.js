﻿function ListarProfesores() {
    EnvioGenerico("/Profesor/Listado", null, "IdListaProfesores")
}

function FormularioProfesor(ProfesorId, Disabled) {
    Global.ProfesorId = ProfesorId == undefined ? 0 : ProfesorId;
    Global.Disabled = Disabled == undefined ? false : true;
    const model = {
        ProfesorId: ProfesorId,
        Disabled: Disabled
    }
    EnvioGenerico("/Profesor/Formulario", model, ModalCrearProfesor)
}

function ModalCrearProfesor(html) {
    // const html = `string text`;

    const ProfesorId = Global.ProfesorId;
    const Disabled = Global.Disabled;
    const title = ProfesorId == 0 ? "Nuevo profesor" :
        (Disabled == true ? "Detalle de profesor" : "Edición de profesor")
    const confirmButtonText = ProfesorId == 0 ? "Guardar información" :
        "Actualizar información";

    const model = {
        title: title,
        html: html,
        confirmButtonText: confirmButtonText,
        showConfirmButton: !Disabled
    };
    ModalCaptura(model, GuardarProfesor);
}

function GuardarProfesor() {
    model = {
        Nombres: $("#NombresProfesor").val(),
        Apellidos: $("#ApellidosProfesor").val(),
        ProfesorId: Global.ProfesorId
    };
    EnvioGenerico("/Profesor/GuardarProfesor", model, MensajeAccionProfesor)
}

function MensajeAccionProfesor(respuesta) {
    if (respuesta.Error != "") {
        AlertaError(respuesta.Error);
    }
    else {
        EnvioGenerico("/Profesor/Listado", null, "IdListaProfesores")
        AlertaExito(respuesta.Exito);
    }
}

function EliminarProfesorForm(ProfesorId, Nombre) {
    Global.ProfesorId = ProfesorId;
    const model = {
        title: "Esta seguro de la eliminación: [" + Nombre + "]",
        confirmButtonText: "Eliminar información",
        cancelButtonText: "Cancelar"
    };
    Confirm(model, EliminarProfesor);
}

function EliminarProfesor() {
    const model = {
        ProfesorId: Global.ProfesorId
    };
    EnvioGenerico("/Profesor/EliminarProfesor", model, MensajeAccionProfesor)
}