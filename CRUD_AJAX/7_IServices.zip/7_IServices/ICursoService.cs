﻿using CursosAJAX.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CursosAJAX.Dominio.IServices
{
    public interface ICursoService
    {
        Task<List<CursoDTO>> ConsultaCursos();
        Task<RespuestaDTO> CrearActualizarCurso(CursoDTO modelo);
        Task<RespuestaDTO> EliminarCurso(CursoDTO modelo);
        Task<CursoDTO> ConsultarCurso(CursoDTO modelo);
        Task<List<SelectListItem>> ListaSeleccionCursos();
    }
}
